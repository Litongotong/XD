/**
 * isBlank関数定義
 * @param value 値 String
 */
export function isBlank(value: string) {
    return value == undefined || value.length == 0
  }

  export const CD_JUGYOIN = 'cdJugyoin'
  export const CD_SONEKIKANRISOSHIKI = 'cdSonekikanriSoshiki'
  export const NM_JUGYOINMYOJI = 'nmJugyoinMyoji'
  export const NM_JUGYOINAMAE = 'nmJugyoinNamae'
  

  


